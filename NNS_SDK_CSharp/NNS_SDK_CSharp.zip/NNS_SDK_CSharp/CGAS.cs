﻿using System;

namespace NNS_SDK_CSharp
{
    public class CGAS
    {

    }
}
